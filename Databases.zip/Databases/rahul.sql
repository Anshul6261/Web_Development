-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2024 at 08:31 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rahul`
--

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'king', 'amitsaini@gmail.com', '$2y$10$eWVVDOmEVxJqoSsORFDKxeQ.YfC6boWQeNdXqiZWmj7zeh2zZEAw6', '2023-10-22 19:23:18'),
(6, '123456', 'amitsaini@gmail.com', '$2y$10$ePK43W3LSULNPtg1tIFW0uc5n2zbKs03bcX03rofpKZQXy4Vwj3j.', '2023-10-22 19:36:44'),
(13, 'amit', 'amitsaini@gmail.com', '$2y$10$GgKkA5om/yKCSBKOp0Mm1esvBDD7UNal/wBiODhc.k3fIGSJ3T7n2', '2023-10-27 12:40:23'),
(22, 'abc', 'amitsaini@gmail.com', '$2y$10$oFHyrbqlFc/QGxSanlgT4OL6BVsKC.tyuHaLZkKfaYp5Y3DEBn2Ta', '2023-10-27 16:44:20'),
(23, 'amit1234', 'amitsaini@gmail.com', '$2y$10$31E.JqDu4qtx.k6y8x3mx.KnWa.J7Urs9oFblQGn/Xvjv3HA1U3K2', '2023-10-27 16:45:13'),
(24, 'AMITsaini', 'amitsaini@gmail.com', '$2y$10$kYiK5AEUKwk1G7XYKdtNM.zHmx1sH4Q9P6V3YtqQg3tEBRCDOHNna', '2023-10-28 10:49:34'),
(25, '123456789', 'amitsaini@gmail.com', '$2y$10$m3NFdx0ZqIPGvrcyxRSSUOzE39yDuFnz81HZIidw1icZjCUUdnvHa', '2023-10-29 17:17:06'),
(26, '1234567890', 'rahulsaini123456789@gmail.com', '$2y$10$6gtEC.1oayctaSAmA92WsOwwvYYYbSTZj.eGcXQ8wpOo3BMaD5cHy', '2023-10-29 17:26:13'),
(27, '1234567', 'rahulsaini123456789@gmail.com', '$2y$10$xxbZrwQdNHARfKg2Kt6Ho.ALVzY/Wpwhn24q42bLeTMnDoPnIcT7C', '2023-10-30 08:58:41'),
(28, '11234567', 'rahulsaini123456789@gmail.com', '$2y$10$xDyWGL0sgCF8.QHqBWFHkOHD9/TGvG.PxbIFK237W1zPjKMd0wFpG', '2023-10-30 08:58:51'),
(29, 'abcdefgh', 'rahulsaini123456789@gmail.com', '$2y$10$vYvJQMr9vvONLA5xsXzEyerPVeF5SdT2DdJebW77cRiL0uXobTpxu', '2023-10-30 10:43:55'),
(30, 'Priyanka', 'priyanka@gmail.com', '$2y$10$Pl98omWgD4bbpc29dvS34OjJxvoY6XfbLXdlFF7u8x2goTnFedgNS', '2023-11-01 06:37:55'),
(31, '123456789000', 'rahulsaini123456789@gmail.com', '$2y$10$lLZPzkhM7jRPgz7c2Ch/2.aNGdY7UifG8xHe1hL4ryGRlNsz/OQta', '2023-12-17 13:51:22'),
(32, '0801CS211020', 'anshkhatik54232@gmail.com', '$2y$10$vEv5.FD.0wbIsQTO/hhAYeWeEjOzJbTRe2GfWnmyheYdK3yF1yeSO', '2023-12-17 14:19:22'),
(33, 'Anshul_Khateek', 'anshkhatik54232@gmail.com', '$2y$10$7vIxSunULqdzjeg/xF3q.uI1JDfeC1AY1WBPO3fSyPH.lY6z891wS', '2023-12-17 14:20:30'),
(34, '456', 'anshulgi54232@gmail.com', '$2y$10$EyP/..GySkzOVrMmbIsloevQ25uapbpB5bXfeXbWY1T3CwNXwSDji', '2023-12-17 14:21:14'),
(35, '08801CS211020', 'anshulgi54232@gmail.com', '$2y$10$YB5WTfR.3secfV79Y/egTepSGsXcAGVAQKJ2oiAnW6xpd9HFJmiHm', '2023-12-17 14:28:03'),
(36, '00880CS211020', 'anshkhatik54232@gmail.com', '$2y$10$SUNaf0DyV8rxoW6S1qzY6.xgBvXOI65HhThvz0G4g9Yad0NT8h.hW', '2023-12-19 07:07:08'),
(37, '789', 'anshkhatik54232@gmail.com', '$2y$10$W8DK2CdNYXgnBWPPdHolS.BOerQiQRBhkr2iyImWwMuyPYNgGLFSe', '2023-12-19 07:07:56'),
(38, '167', 'anshkhatik54232@gmail.com', '$2y$10$aCiDourkq3swHC9TUxVMuu8brg3F9Q.VS8ZVHLW/dhGIEwkcFEjXW', '2023-12-19 07:18:34'),
(39, 'Sahil ', 'anshulgi54232@gmail.com', '$2y$10$XqGryOhbLpbXfJ.mrUQ4buhyrDBLZkz9vZWA62diod2VGSKVDvdja', '2023-12-19 08:58:47'),
(40, 'naveen', 'anshulgi54232@gmail.com', '$2y$10$eozFq90mxg83Bssf5LUuwel0sb2ZeLt9IN03waWuC/zufnVKFpxry', '2023-12-22 04:23:14'),
(41, 'ajay', 'anshkhatik54232@gmail.com', '$2y$10$SSNdODCllT7ZhDcsP9BG8O468YJutJT8i6aNO114udlelTxMGrjhK', '2023-12-22 05:52:35'),
(42, 'ram', 'anshkhatik54232@gmail.com', '$2y$10$UFp89fUbMcu1o0lbyfm4jurF7o4rguIxuZevpAENav1FrKB.DzDWO', '2023-12-22 05:57:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
