-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2024 at 08:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip_code` varchar(6) NOT NULL,
  `card_name` varchar(255) NOT NULL,
  `card_number` varchar(20) NOT NULL,
  `exp_month` varchar(20) NOT NULL,
  `exp_year` varchar(4) NOT NULL,
  `cvv` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `full_name`, `email`, `address`, `city`, `state`, `zip_code`, `card_name`, `card_number`, `exp_month`, `exp_year`, `cvv`) VALUES
(2, 'Rahul saini', 'rahulsaini123456789@gmail.com', 'Guna', 'Guna', 'MP', '473226', 'Rahul saini', '1111 2222 3333 4444', 'March', '2025', '123'),
(16, 'rahul saini', 'rahulsaini123456789@gmail.com', 'WARD NO 03 RAGHOGARH DIST GUNA', 'guna', 'Madhya Pradesh', '473226', 'rahul saini', '1111 2222 3333 4444', '05/2050', '2025', '123'),
(17, '', '', '', '', '', '', '', '', '', '', ''),
(18, '', '', '', '', '', '', '', '', '', '', ''),
(19, 'amit saini', 'amitsaini@gmail.com', 'raghogarh', 'guna', 'madhya pradesh', '473226', 'Amit Saini', '1111-1111-1111-1111', 'March', '2025', '123'),
(20, 'rahul saini', 'rahulsaini123456789@gmail.com', 'WARD NO 03 RAGHOGARH DIST GUNA', 'guna', 'Madhya Pradesh', '473226', '111111111111', '8451365', 'march', '2024', '123'),
(21, 'rahul saini', 'rahulsaini123456789@gmail.com', 'WARD NO 03 RAGHOGARH DIST GUNA', 'guna', 'Madhya Pradesh', '473226', '', '', '', '', ''),
(22, 'Anshul Khateek', '', 'Indore , MP', 'Indore', 'Madhya Pradesh', '452003', '', '', '', '', ''),
(23, 'Anshul Khateeknnnnn', '', 'Indore , MP', 'Indore', 'Madhya Pradesh', '452003', '', '', '', '', ''),
(24, 'sahil dayani', 'anshulgi54232@gmail.com', 'gwalior', 'gwalior', 'mp', '452003', '5335434354', '2343243243', '12', '455', '664'),
(25, 'Anshul Khateek', '', 'Indore , MP', 'Indore', 'Madhya Pradesh', '452003', '', '', '', '', ''),
(26, 'ajay', 'anshkhatik54232@gmail.com', 'Indore , MP', 'Indore', 'Madhya Pradesh', '452003', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
